# Rights and licensing

No public redistribution or reuse license is granted by this package. An explicit license must be selected by the rights holder before an openly licensed release. Copyright and attribution in third-party evidence sources remain unchanged. Raw upstream event logs are not redistributed here.
